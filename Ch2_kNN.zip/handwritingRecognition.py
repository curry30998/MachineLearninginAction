# -*- coding=utf-8 -*-
# Time: 2021/4/17 0017
# Name: handwritingRecognition.py
# Tool: PyCharm
# @author: Curry
# Address: zm_seu@seu.edu.cn
